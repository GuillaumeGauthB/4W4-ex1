 <?php
     /**
      *  Template pour afficher le footer
      */
 ?>

 <footer class="site__footer">

     <div class="site__info">
         
         <section class="site__info__adresse">
             <p>3 800, rue Sherbrook Est Montréal</p>
             <p>(Québec) H1x 2A2</p>
             <p>514-254-7131</p>
             <p>Lorem ipsum dolor sit</p>
             <p>Lorem ipsum dolor sit</p>
             <p>Lorem ipsum dolor sit</p>
             
         </section>

         <section class="site__info__liens">
             <a href="" class="site__info__liens__a">Nouveau lien</a>
             <a href="" class="site__info__liens__a">Nouveau lien</a>
             <a href="" class="site__info__liens__a">Nouveau lien</a>
             <a href="" class="site__info__liens__a">Nouveau lien</a>
             <a href="" class="site__info__liens__a">Nouveau lien</a>
             <a href="" class="site__info__liens__a">Nouveau lien</a>
             <a href="" class="site__info__liens__a">Nouveau lien</a>
         </section>

         <section class="site__info__nouvelle">
             <p>Lorem ipsum dolor sit amet consectetur</p>
         </section>
     </div>

     <div class="site__info2">
         <nav class="site__info2__menu">
             <a href="#" class="site__info2__menu__a">Choix 1</a>
             <a href="#" class="site__info2__menu__a">Choix 2</a>
             <a href="#" class="site__info2__menu__a">Choix 3</a>
             <a href="#" class="site__info2__menu__a">Choix 4</a>
             <a href="#" class="site__info2__menu__a">Choix 5</a>
         </nav>

         <section class="site__info2__droit">
             <p>Copyright 2022 - College de Maisonneuve.</p>
         </section>
     </div>
     <?php wp_footer(); ?>
</body>
</html>




















 </footer>